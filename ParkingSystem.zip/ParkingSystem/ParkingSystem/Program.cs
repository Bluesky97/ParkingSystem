﻿using Microsoft.Extensions.Configuration;
using ParkingSystem.DAL;
using ParkingSystem.Model;
using System;
using System.IO;

namespace ParkingSystem
{
    class Program
    {
        private static IConfiguration _iconfiguration;
        static void Main(string[] args)
        {
            GetAppSettingsFile();

            int parkingLot;
            string plateNumber, carColor, model;
            Console.WriteLine("Enter Parking Lot: ");
            parkingLot = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("MENU");
            Console.WriteLine("1. ADD PARKING SYSTEM");
            Console.WriteLine("2. REMOVE PARKING SYSTEM");
            Console.WriteLine("3. LIST OF ALL PARKING SYSTEM");
            Console.WriteLine("4. ODD PLATE NUMBER");
            Console.WriteLine("5. EVEN PLATE NUMBER");
            Console.WriteLine("6. WHITE COLOR CAR PLATE NUMBER");
            Console.WriteLine("7. SLOT NUMBER COLOR PUTIH");
            Console.WriteLine("8. SEARCH SLOT NUMBER BY PLATE NUMBER");
            Console.WriteLine("9. TYPE OF MOBIL");
            Console.WriteLine("10. TYPE OF MOTOR");

            Console.Write("Enter Choice: ");
            int choice = Convert.ToInt32(Console.ReadLine());
            bool loopContinue = true;
            while (loopContinue)
            {
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter Plate Number: ");
                        plateNumber = Console.ReadLine();
                        Console.WriteLine("Enter Car Color: ");
                        carColor = Console.ReadLine();
                        Console.WriteLine("Enter Model: ");
                        model = Console.ReadLine();
                        var parkingSystemDAL = new ParkingSystemDAL(_iconfiguration);
                        var parkingModel = parkingSystemDAL.GetCount();
                        Random rndRandom = new Random();
                        int getNewParkingId = rndRandom.Next(1, 1000);
                        if (parkingLot > parkingModel)
                        {
                            ParkingSystemModel parkingSystemModel = new ParkingSystemModel()
                            {
                                parkingId = getNewParkingId,
                                plateNumber = plateNumber,
                                carColor = carColor,
                                model = model
                            };
                            parkingSystemDAL.InsertParking(parkingSystemModel);
                            loopContinue = true;
                        }
                        else
                        {
                            Console.WriteLine("Sorry, No Parking Lot!!!");
                            break;
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter Parking ID: ");
                        int parkingId = Convert.ToInt32(Console.ReadLine());
                        var parkingSystemDAL1 = new ParkingSystemDAL(_iconfiguration);
                        var parkingModel1 = parkingSystemDAL1.GetCount();
                        ParkingSystemModel parkingSystemModel1 = new ParkingSystemModel()
                        {
                            parkingId = parkingId,
                        };
                        parkingSystemDAL1.DeleteParking(parkingSystemModel1);
                        loopContinue = true;
                        break;
                    case 3:
                        PrintParkingSystem();
                        loopContinue = true;
                        break;
                    case 4:
                        loopContinue = false;
                        var parkingSystemDAL2 = new ParkingSystemDAL(_iconfiguration);
                        var listParkingModel = parkingSystemDAL2.GetList();
                        listParkingModel.ForEach(item =>
                        {
                            string newPlateNumber = item.plateNumber.Substring(2, 4);
                            int[] array = { Convert.ToInt32(newPlateNumber) };
                            foreach (var result in array)
                            {
                                if (result % 2 != 0)
                                {
                                    Console.WriteLine(item.plateNumber);
                                }
                            }
                        });
                        break;
                    case 5:
                        loopContinue = false;
                        var parkingSystemDAL3 = new ParkingSystemDAL(_iconfiguration);
                        var listParkingModel1 = parkingSystemDAL3.GetList();
                        listParkingModel1.ForEach(item =>
                        {
                            string newPlateNumber = item.plateNumber.Substring(2, 4);
                            int[] array = { Convert.ToInt32(newPlateNumber) };
                            foreach (var result in array)
                            {
                                if (result % 2 == 0)
                                {
                                    Console.WriteLine(item.plateNumber);
                                }
                            }
                        });
                        break;
                    case 6:
                        loopContinue = false;
                        var parkingSystemWhiteCarDAL = new ParkingSystemDAL(_iconfiguration);
                        var listParkingModelWhiteCar = parkingSystemWhiteCarDAL.GetList();
                        listParkingModelWhiteCar.ForEach(item =>
                        {
                            var newItem = item.carColor == "PUTIH";
                            if (newItem == true)
                            {
                                Console.WriteLine(item.plateNumber);
                            }
                        });
                        break;
                    case 7:
                        loopContinue = false;
                        var parkingSlotWhiteColorCarDAL = new ParkingSystemDAL(_iconfiguration);
                        var listParkingSlotWhiteCar = parkingSlotWhiteColorCarDAL.GetList();
                        listParkingSlotWhiteCar.ForEach(item =>
                        {
                            var newItem = item.carColor == "PUTIH";
                            if (newItem == true)
                            {
                                Console.WriteLine(item.parkingId);
                            }
                        });
                        break;
                    case 8:
                        loopContinue = false;
                        Console.WriteLine("Enter Plate Number: ");
                        string plateNumber1 = Console.ReadLine();
                        var searchPlateNumberDAL = new ParkingSystemDAL(_iconfiguration);
                        var listSlotParking = searchPlateNumberDAL.GetList();
                        foreach (var result in listSlotParking)
                        {
                            bool searchItem = result.plateNumber == plateNumber1;
                            if (searchItem == true)
                            {
                                Console.WriteLine(result.parkingId);
                            }
                            else
                            {
                                Console.WriteLine("Not Found");
                            }
                        }
                        break;
                    case 9:
                        loopContinue = false;
                        var parkingSystemDAL123 = new ParkingSystemDAL(_iconfiguration);
                        var typeMobil = parkingSystemDAL123.GetCountMobil();
                        Console.WriteLine(typeMobil);
                        break;
                    case 10:
                        loopContinue = false;
                        var parkingSystemDAL12 = new ParkingSystemDAL(_iconfiguration);
                        var typeMotor = parkingSystemDAL12.GetCountMotor();
                        Console.WriteLine(typeMotor);
                        break;
                    default:
                        Console.WriteLine("Wrong Input!!!");
                        loopContinue = true;
                        break;
                }
            }
            if (loopContinue)
                Console.WriteLine("Please enter a valid choice");
        }

        static void PrintParkingSystem()
        {
            var parkingSystemDAL = new ParkingSystemDAL(_iconfiguration);
            var listParkingModel = parkingSystemDAL.GetList();
            listParkingModel.ForEach(item =>
            {
                Console.WriteLine(Convert.ToString(item.parkingId) + " " + item.plateNumber + " " + item.model + " " + item.carColor);
            });
            Console.ReadKey();
        }
        public static bool FindEvenOdd(bool isEven)
        {
            var parkingSystemDAL = new ParkingSystemDAL(_iconfiguration);
            var listParkingModel = parkingSystemDAL.GetList();
            listParkingModel.ForEach(item =>
            {
                string newPlateNumber = item.plateNumber.Substring(2, 4);
                int[] array = { Convert.ToInt32(newPlateNumber) };
                foreach (var result in array)
                {
                    if (result % 2 == 0)
                    {
                        isEven = true;
                    }
                    else
                    {
                        isEven = false;
                    }
                }
            });
            return isEven;
        }
        public int CountParkingSystem()
        {
            var parkingSystemDAL = new ParkingSystemDAL(_iconfiguration);
            var parkingModel = parkingSystemDAL.GetCount();
            Console.ReadKey();

            return parkingModel;
        }
        static void GetAppSettingsFile()
        {
            var builder = new ConfigurationBuilder()
                     .SetBasePath(Directory.GetCurrentDirectory())
                     .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            _iconfiguration = builder.Build();
        }
    }
}
