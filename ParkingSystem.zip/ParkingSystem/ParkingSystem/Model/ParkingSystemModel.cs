﻿namespace ParkingSystem.Model
{
    public class ParkingSystemModel
    {
        public int parkingId { get; set; }
        public string plateNumber { get; set; }
        public string carColor { get; set; }
        public string model { get; set; }
    }
}
