﻿using Microsoft.Extensions.Configuration;
using ParkingSystem.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ParkingSystem.DAL
{
    public class ParkingSystemDAL
    {
        private string _connectionString;
        public ParkingSystemDAL(IConfiguration iconfiguration)
        {
            _connectionString = iconfiguration.GetConnectionString("Default");
        }
        public List<ParkingSystemModel> GetList()
        {
            var listParkingModel = new List<ParkingSystemModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("select * from parkinghistory", con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        listParkingModel.Add(new ParkingSystemModel
                        {
                            parkingId = rdr.GetInt32("parkingId"),
                            plateNumber = rdr.GetString("plateNumber"),
                            carColor = rdr.GetString("carColor"),
                            model = rdr.GetString("model")
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listParkingModel;
        }
        public List<ParkingSystemModel> GetListPlateNumber()
        {
            var listParkingModel = new List<ParkingSystemModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("select plateNumber from parkinghistory", con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        listParkingModel.Add(new ParkingSystemModel
                        {
                            parkingId = rdr.GetInt32("parkingId"),
                            plateNumber = rdr.GetString("plateNumber"),
                            carColor = rdr.GetString("carColor"),
                            model = rdr.GetString("model")
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listParkingModel;
        }
        public List<ParkingSystemModel> GetListParkingId(ParkingSystemModel p)
        {
            var listParkingModel = new List<ParkingSystemModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("select parkingId from parkinghistory where plateNumber=@plateNumber", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@plateNumber", p.plateNumber);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listParkingModel;
        }
        public int GetCount()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("select count(*) from parkinghistory", con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    Int32 count = (Int32)cmd.ExecuteScalar();
                    return count;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int GetCountMobil()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("select count(*) from ParkingHistory where model = 'MOBIL'", con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    Int32 count = (Int32)cmd.ExecuteScalar();
                    return count;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int GetCountMotor()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("select count(*) from ParkingHistory where model = 'MOTOR'", con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    Int32 count = (Int32)cmd.ExecuteScalar();
                    return count;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<ParkingSystemModel> InsertParking(ParkingSystemModel p)
        {
            var parkingModel = new List<ParkingSystemModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("insert into ParkingHistory (parkingId, plateNumber, carColor, model) values (@parkingId, @plateNumber, @carColor, @model)", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@parkingId", p.parkingId);
                    cmd.Parameters.AddWithValue("@plateNumber", p.plateNumber);
                    cmd.Parameters.AddWithValue("@carColor", p.carColor);
                    cmd.Parameters.AddWithValue("@model", p.model);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return parkingModel;
        }
        public List<ParkingSystemModel> DeleteParking(ParkingSystemModel p)
        {
            var parkingModel = new List<ParkingSystemModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand("delete from ParkingHistory where parkingId = @parkingId", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@parkingId", p.parkingId);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return parkingModel;
        }
    }
}
