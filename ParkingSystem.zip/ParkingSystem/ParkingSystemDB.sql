--create database ParkingSystemDB

use ParkingSystemDB

CREATE TABLE ParkingHistory
(
parkingId		int primary key,
plateNumber		varchar(25),
carColor		varchar(25),
model			varchar(25)
);

insert into ParkingHistory values (1, 'B-1023-UOI', 'PUTIH', 'MOBIL');
select * from parkinghistory;